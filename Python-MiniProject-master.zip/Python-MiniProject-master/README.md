# Pythonゲームプログラミング初級【パックマン】

![capture-2](https://user-images.githubusercontent.com/58985013/97005659-b1043080-1579-11eb-9fe0-ad0ec168de0b.jpg)
https://youtu.be/V2u1FRjIuD4

# 環境設定
Pygameというライブラリを使います。

https://www.pygame.org/wiki/GettingStarted

pythonのバージョンは3.7.7以上を使用してください。僕は3.7.7でうまく行きました。環境によっては3.8でうまくいかない場合があります。
